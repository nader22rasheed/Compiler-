package AST.CSS;

public interface NeastedStatementNode {
    void print(int indent);
    int getLineNumber();
}