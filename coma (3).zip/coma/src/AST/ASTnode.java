package AST;

import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;
import java.io.IOException;

/**
 * Base abstract AST node.
 * - يحوي اسم العقدة، رقم السطر، وقائمة الأبناء.
 * - يوفر دالة لحفظ الشجرة إلى ملف (saveToFile)، ودوال مساعدة للمسافات.
 * - كل صنف فرعي يجب أن يعرّف print(int indent).
 */
public abstract class ASTnode {
    protected String nodeName;
    protected int lineNumber;
    protected List<ASTnode> children;

    public ASTnode(String nodeName) {
        this(nodeName, 0);
    }

    public ASTnode(String nodeName, int lineNumber) {
        this.nodeName = nodeName != null ? nodeName : "";
        this.lineNumber = lineNumber;
        this.children = new ArrayList<>();
    }

    /** أضف ابنًا للعقدة */
    public void addChild(ASTnode child) {
        if (child != null) this.children.add(child);
    }

    public List<ASTnode> getChildren() {
        return this.children;
    }

    /** Getter لاسم العقدة — يحل مشكلة استدعاء getNodeName() */
    public String getNodeName() {
        return this.nodeName;
    }

    /** Alias إن استدعى أحدهم getName() */
    public String getName() {
        return this.nodeName;
    }

    /** Getter لرقم السطر — يحل مشكلة استدعاء getLineNumber() */
    public int getLineNumber() {
        return this.lineNumber;
    }

    /** Setter لرقم السطر (قد يفيد أثناء بناء الشجرة) */
    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    /** Setter لاسم العقدة */
    public void setNodeName(String name) {
        this.nodeName = name;
    }

    /** دالة لحفظ الشجرة النصية إلى ملف (قابلة لإعادة الاستخدام) */
    public void saveToFile(String filename) throws IOException {
        try (PrintWriter pw = new PrintWriter(filename)) {
            save(pw, 0);
        }
    }

    /** تنفيذ الحفظ إلى PrintWriter مع التحكّم في المسافة (indent) */
    protected void save(PrintWriter pw, int indent) {
        // اطبع السطر الخاص بهذه العقدة
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < indent; i++) sb.append("  ");
        sb.append(this.toString());
        pw.println(sb.toString());

        // اطبع الأبناء
        for (ASTnode c : children) {
            if (c != null) c.save(pw, indent + 1);
        }
    }

    /** كل صنف فرعي يجب أن يعرّف طريقة الطباعة الخاصة به */
    public abstract void print(int indent);

    @Override
    public String toString() {
        return nodeName + " (Line: " + lineNumber + ")";
    }

    /** دالة مساعدة لطباعة المسافات في الطباعة على الشاشة */
    protected void printIndent(int indent) {
        for (int i = 0; i < indent; i++) System.out.print("  ");
    }
}
