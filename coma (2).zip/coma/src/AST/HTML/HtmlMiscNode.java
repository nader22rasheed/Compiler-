package AST.HTML;

import AST.ASTnode;

// ====================== 9. htmlMisc ======================
public abstract class HtmlMiscNode extends ASTnode {
    public HtmlMiscNode(String name, int line) {
        super(name, line);
    }
}
