package AST;

import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;
import java.io.IOException;


public abstract class ASTnode {
    protected String nodeName;
    protected int lineNumber;

    public ASTnode(String nodeName) {
        this.nodeName = nodeName;
    }

    public List<ASTnode> getChildren() {
        return children;
    }
    public int getLineNumber() {
        return lineNumber;
    }

    protected List<ASTnode> children = new ArrayList<>();


    public String getNodeName() {
        return nodeName;
    }


    public ASTnode(String nodeName, int lineNumber) {
        this.nodeName = nodeName;
        this.lineNumber = lineNumber;
    }

    public void addChild(ASTnode child) {
        if (child != null) {
            children.add(child);
        }
    }

    public abstract void print(int indent);
    public void save(PrintWriter pw, int indent) {
        for (int i = 0; i < indent; i++) pw.print("  ");
        pw.println(this.toString());
        for (ASTnode child : this.getChildren()) {
            if (child != null) child.save(pw, indent + 1);
        }
    }


    public void saveToFile(String filename) throws IOException {
        try (PrintWriter pw = new PrintWriter(filename)) {
            save(pw, 0);
        }
    }
    @Override
    public String toString() {
        return nodeName + " (Line: " + lineNumber + ")";
    }

    protected void printIndent(int indent) {
        for (int i = 0; i < indent; i++) System.out.print("  ");

    }
}