package AST.JINJA;

import AST.ASTnode;

public abstract class JinjaExpressionInnerNode extends ASTnode {
    public JinjaExpressionInnerNode(String name, int line) {
        super(name, line);
    }
}
