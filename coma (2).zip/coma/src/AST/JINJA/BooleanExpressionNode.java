package AST.JINJA;

import AST.ASTnode;

public abstract class BooleanExpressionNode extends ASTnode {
    public BooleanExpressionNode(String name, int line) {
        super(name, line);
    }
}
